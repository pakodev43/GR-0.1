
// Welcome!
// Change the values of each element according to your need.
// After changing, save this file and reload your website. The data will be updated on the website.
// All the data here will be visible publically on your website.



var data = {
    
    // Enter the title. This will be the title shown in Google search results.
    title : "Abdullah Khan's Portfolio",

    // Enter the description. This description will be visible in Google search under the site's title.
    description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet vulputate tristique quam felis. Id phasellus dui orci vulputate consequat nulla proin. Id sit scelerisque neque, proin bibendum diam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet vulputate tristique quam felis.',

    // Enter your site's keywords separated  by commas.
    keywords : 'keyword1, keyword2, keyword3',



    // Update your information in these fields

    name : 'Abdullah Khan',
    role : 'Social Media Marketer',
    country : 'Pakistan',
    about : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet vulputate tristique quam felis. Id phasellus dui orci vulputate consequat nulla proin. Id sit scelerisque neque, proin bibendum diam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet vulputate tristique quam felis. Id phasellus dui orci vulputate consequat nulla proin. Id sit scelerisque neque, proin bibendum diam.',
    
    
    
    // Add the names of portfolio items
    
    portfolio_item_name_1 : 'Job portal for New Jersey',
    portfolio_item_name_2 : 'Node app to track sales',
    portfolio_item_name_3 : 'Gym app for android',
    portfolio_item_name_4 : 'Hotel managment website',
    portfolio_item_name_5 : 'React app for traveling agency',
    portfolio_item_name_6 : 'Managment website',
    
    
    
    // This is contact section data. Change it according to your need
    
    email : 'mail@me.com',
    phoneNumber : '+00 01 0123456789',
    contact_section_text_bold : 'Let’s Talk for something Special',
    contact_section_text : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sed aliquam sollicitudin rhoncus morbi. Tincidunt quam sem elit.',



    // Add the links of your social media profiles here

    facebook_profile_link : 'https://www.facebook.com/',
    linkedin_profile_link : 'https://www.linkedin.com/',
    instagram_profile_link : 'https://www.instagram.com/',
    x_profile_link : 'https://www.x.com/',


}


















































// var name = {
//     title,
//     logoName,
//     heading,
//     footer
// }

// var name.logoName = document.getElementById('logoName')
// var title = document.querySelector('[data-type]')
// // var title = document.querySelectorAll('[data-type]')
// // document.get


// var data = {

//     name : 'Abdullah Khan kjj',
//     logoName : 'Abdullah Khan',

// }

// title.textContent = data.title
// logoName.textContent = data.logoName