

var title = document.querySelector('[data-owner="title"]')
var description = document.querySelector('[data-meta="description"]')
var keywords = document.querySelector('[data-meta="keywords"]')


var logo = document.querySelector('[data-owner="logo"]')
var nameInHeading = document.querySelector('[data-owner="nameInHeading"]')
var nameInFooter = document.querySelector('[data-owner="nameInFooter"]')
var role = document.querySelector('[data-owner="role"]')
var basedIn = document.querySelector('[data-owner="basedIn"]')
var email = document.querySelector('[data-owner="email"]')
var phoneNumber = document.querySelector('[data-owner="phoneNumber"]')
var about = document.querySelector('[data-owner="about"]')


var portfolioItem1 = document.querySelector('[data-portfolio-item="1"]')
var portfolioItem2 = document.querySelector('[data-portfolio-item="2"]')
var portfolioItem3 = document.querySelector('[data-portfolio-item="3"]')
var portfolioItem4 = document.querySelector('[data-portfolio-item="4"]')
var portfolioItem5 = document.querySelector('[data-portfolio-item="5"]')
var portfolioItem6 = document.querySelector('[data-portfolio-item="6"]')


var contact_section_text_bold = document.querySelector('[data-owner="contact_section_text_bold"]')
var contact_section_text = document.querySelector('[data-owner="contact_section_text"]')


var facebookLinkHeader = document.querySelector('[data-social-media-link-header="facebook"]')
var facebookLinkFooter = document.querySelector('[data-social-media-link-footer="facebook"]')
var linkedinLinkHeader = document.querySelector('[data-social-media-link-header="linkedin"]')
var linkedinLinkFooter = document.querySelector('[data-social-media-link-footer="linkedin"]')
var instagramLinkHeader = document.querySelector('[data-social-media-link-header="instagram"]')
var instagramLinkFooter = document.querySelector('[data-social-media-link-footer="instagram"]')
var xLinkHeader = document.querySelector('[data-social-media-link-header="x"]')
var xLinkFooter = document.querySelector('[data-social-media-link-footer="x"]')