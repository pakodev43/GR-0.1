

title.textContent = data.title
description.content = data.description
keywords.content = data.keywords


logo.textContent = data.name
nameInHeading.textContent = data.name
nameInFooter.textContent = data.name
role.textContent = data.role
basedIn.textContent = data.country
email.textContent = data.email
phoneNumber.textContent = data.phoneNumber
about.textContent = data.about


portfolioItem1.textContent = data.portfolio_item_name_1
portfolioItem2.textContent = data.portfolio_item_name_2
portfolioItem3.textContent = data.portfolio_item_name_3
portfolioItem4.textContent = data.portfolio_item_name_4
portfolioItem5.textContent = data.portfolio_item_name_5
portfolioItem6.textContent = data.portfolio_item_name_6


contact_section_text_bold.textContent = data.contact_section_text_bold
contact_section_text.textContent = data.contact_section_text


facebookLinkHeader.href = data.facebook_profile_link
facebookLinkFooter.href = data.facebook_profile_link
linkedinLinkHeader.href = data.linkedin_profile_link
linkedinLinkFooter.href = data.linkedin_profile_link
instagramLinkHeader.href = data.instagram_profile_link
instagramLinkFooter.href = data.instagram_profile_link
xLinkHeader.href = data.x_profile_link
xLinkFooter.href = data.x_profile_link